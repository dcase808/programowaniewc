#!/bin/bash

echo entered $# arguments

for i in $*
do
echo $i
done